#!/bin/bash

backup_dir=$1
dest_dir=$2

backup_date=$(date +%b-%d-%y)

echo "Starting backup of: $backup_dir "

sudo tar -Pczf "$dest_dir-$backup_date.tar.gz" $backup_dir
if [ $? -eq 0 ]; then
	echo "$backup_dir backup succeeded"
else
	echo "$backup_dir backup failed"
fi

echo "Backup is done!"
